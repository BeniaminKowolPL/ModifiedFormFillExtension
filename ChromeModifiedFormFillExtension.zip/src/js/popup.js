window.onload = () => {
  const fillInBtn = document.getElementById('fill-in-btn');
  fillInBtn.addEventListener('click', fillIn);

  const saveBtn = document.getElementById('save-btn');
  saveBtn.addEventListener('click', save);

  const autoFillInput = document.getElementById('auto-fill-checkbox');
  autoFillInput.addEventListener('change', autoFillValueChanged)
  chrome.storage.sync.get('settings', (result) => {
    const autoFill = result['settings']?.autoFill === undefined ? true : result['settings']?.autoFill;
    autoFillInput.checked = !!autoFill;
  });
};

async function fillIn() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    files: ['src/js/fill-in.js'],
  });
  window.close();
};

async function save() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    files: ['src/js/save.js'],
  });
  window.close();
};

async function autoFillValueChanged(cb) {
  const checked = cb.target.checked;
  chrome.storage.sync.set({ settings: {
    autoFill: checked
  }}, () => {});
}
