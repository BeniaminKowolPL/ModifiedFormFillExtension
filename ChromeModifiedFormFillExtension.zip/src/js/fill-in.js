function fetchFillIns(completion) {
  let key = window.location.host + window.location.pathname;
  chrome.storage.sync.get(key, (items) => {
    let fillIns = items[key] || [];
    completion(fillIns);
  });
};

function getAllTextInputs() {
  return [].slice.call(document.querySelectorAll('input'));
}

function dataMigratorV1_1(oldData) {
  return oldData.className
    ? oldData
    : {
        id: oldData.id || '',
        name: oldData.name || '',
        className: oldData.class || '',
        value: oldData.value || '',
      };
};

function fillInInput(data) {
  const inputs = getAllTextInputs();
  inputs
    .filter(
      (input) =>
        (input.id + input.name + input.className).trim() ===
        (data.id + data.name + data.className).trim()
    )
    .forEach((input) => {
      input.value = data.value;
      input.dispatchEvent(new Event('change', {
        bubbles: true,
        cancelable: false,
      }));
    });
};

function fillInRecordedInputs() {
  fetchFillIns((fillIns) =>
    fillIns.map(dataMigratorV1_1).forEach((data) => fillInInput(data))
  );
};

fillInRecordedInputs();
