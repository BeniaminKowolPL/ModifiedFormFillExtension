chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  chrome.storage.sync.get('settings', (result) => {
    const autoFill = result['settings']?.autoFill === undefined ? true : result['settings']?.autoFill;
    if (!!autoFill) {
      chrome.scripting.executeScript({
        target: { tabId },
        files: ['src/js/fill-in.js'],
      });
    }
  });
});
